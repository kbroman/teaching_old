######################################################################
# npmix.R
#
# Karl W Broman, Johns Hopkins University
# 1 Dec 2003
#
# Code for getting MLEs via the EM algorithm for a normal/Poisson
# mixture model.  Written as an illustration for the course
# 140.776 (Statistical computing).
#
# This version calls C code (in npmix.c)
#
# The problem:
# 
# m groups, n_i values in group i.  
# y_ij: quantitative responses (j=1...n_i, i=1...m)
# k_ij: unobserved counts
#
# (k_ij, y_ij) mutually independent
# k_ij ~ Poisson(lambda_i)
# y_ij | k_ij ~ Normal(mean=a + b k_ij, sd = sigma)
#
# Obtain MLEs of a, b, sigma, lambda_1 ..., lambda_m by EM
#
# Contains: npmix.em, npmix.sim
######################################################################

######################################################################
# npmix.em
#
# The main function for performing EM
#
# Input:
#   y:       a list; components are the m groups; values in each
#            component are the y_ij
#
#   start:   a vector of starting values for
#            theta = (a,b,sigma,lambda_1,...,lambda_m)
#
#   maxk:    maximum value of k for sums over poisson counts
#
#   maxit:   maximum number of iterations
#
#   tol:     tolerance for determining convergence
#
#   trace:   FALSE/0: give no tracing info
#            TRUE/1:  print change in ln lik + max change in param
#            2:       print delta lnlik and current param ests 
#
# Output:    A list containing the following:
#
#   est:     estimate of theta = (a, b, sigma, lambda_1 ... lambda_m)
#   lnlik:   ln likelihood at the estimate
#   ek:      E(k | theta_hat, y)   [a list like "y" in the input]
#   eksq:    E(k^2 | theta_hat, y) [same structure as ek]
#
######################################################################

npmix.em <-
function(y, start, maxk=30, maxit=1000, tol=1e-6, trace=FALSE)
{
  # check the input
  if(!is.list(y)) stop("y should be a list.")
  if(length(y) < 2) stop("y should have length >= 2.")
  if(length(start) != length(y)+3)
    stop("length(start) should = length(y)+3.")

  # get rid of NA's
  n.na <- sum(is.na(unlist(y)))
  if(n.na > 0) {
    warning("Omitting ", n.na, " NAs from the input, y.")
    y <- lapply(y, function(a) a[!is.na(a)])
  }

  n.grps <- length(y)     # no. groups
  n.obs <- sapply(y, length) # no. data pts per group

  # load the C code
  if(!is.loaded(symbol.C("R_npmix_em"))) {
    lib.file <- file.path(paste("npmix", .Platform$dynlib.ext, sep=""))
    dyn.load(lib.file)
    cat(" -Loaded ", lib.file, "\n")
  }

  output <- .C("R_npmix_em",
               as.double(unlist(y)),
               as.integer(n.grps),
               as.integer(n.obs),
               est=as.double(start),
               lnlik=as.double(0),
               ek=as.double(rep(0,sum(n.obs))),
               eksq=as.double(rep(0,sum(n.obs))),
               as.integer(maxk),
               as.integer(maxit),
               as.double(tol),
               as.integer(trace))

  # pull out just the named bits
  result <- output[c("est","lnlik","ek","eksq")]
  
  # make ek and eksq lists like the data, y
  ek <- result$ek
  eksq <- result$eksq
  result$ek <- result$eksq <- vector("list",n.grps)
  cur <- 1
  for(i in 1:n.grps) {
    result$ek[[i]] <- ek[cur:(cur+n.obs[i]-1)]
    result$eksq[[i]] <- eksq[cur:(cur+n.obs[i]-1)]
    cur <- cur + n.obs[i]
  }

  names(result$est) <- c("a","b","sigma",paste("lambda_", 1:length(y),sep=""))

  result
}


######################################################################
# npmix.sim: Simulate data for testing the npmix.em program
#
# Input:
#     n:      = (n_1, n_2, ..., n_m) = no. observations in each group
#     theta:  The parameter values = (a, b, sigma, theta_1 ... theta_m)
#
# Output:
#     A list like "y" for the input to npmix.em
######################################################################

npmix.sim <-
function(n=c(30,30,30,30), theta=c(10,1,0.3, 0.1, 1.1, 2.1, 3.1))
{
  if(length(n)+3 != length(theta))
    stop("length(theta) should = length(n)+3.")

  lambda <- theta[-(1:3)]
  a <- theta[1]
  b <- theta[2]
  sigma <- theta[3]

  y <- vector("list", length(n))
  for(i in 1:length(y)) 
    y[[i]] <- rnorm(n[i], a+b*rpois(n[i],lambda[i]), sigma)

  y
}

# end of npmix.R
