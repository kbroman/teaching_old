/**********************************************************************
 * 
 * npmix.c
 *
 * Karl W Broman, Johns Hopkins University
 * 1 Dec 2003
 *
 * Code for getting MLEs via the EM algorithm for a normal/Poisson
 * mixture model.  Written as an illustration for the course
 * 140.776 (Statistical computing).
 *
 * The problem:
 * 
 * m groups, n_i values in group i.  
 * y_ij: quantitative responses (j=1...n_i, i=1...m)
 * k_ij: unobserved counts
 *
 * (k_ij, y_ij) mutually independent
 * k_ij ~ Poisson(lambda_i)
 * y_ij | k_ij ~ Normal(mean=a + b k_ij, sd = sigma)
 *
 * Obtain MLEs of a, b, sigma, lambda_1 ..., lambda_m by EM
 *
 * Contains: npmix_em, R_npmix_em, npmix_estep, npmix_mstep,
 *           npmix_lnlik
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <R.h>
#include <Rmath.h>
#include <R_ext/PrtUtil.h>
#include "npmix.h"

/*****************************************************************
 * npmix_em
 *
 * The main function for the EM algorithm
 *
 * Input:
 * 
 *     y        The data referred to as y[group][obs within group]
 *     n_grps   The number of groups ("m")
 *     n_obs    The number of observations per group 
 *              [length n_grps]
 *     est      On entry, the starting points for the parameter 
 *                  estimates [length n_grps+3]; on exit, the 
 *                  estimates themselves.
 *     lnlik    On exit, the value of the log likelihood evaluated 
 *                  at the converged values of the estimates.
 *     ek       On exit, E(k | y, est) [same structure as y]
 *     eksq     On exit, E(k^2 | y, est) [same structure as y]
 *
 *****************************************************************/
 
void npmix_em(double **y, int n_grps, int *n_obs, double *est,
	      double *lnlik, double **ek, double **eksq, 
	      int maxk, int maxit, double tol, int trace)
{
  int i, j, flag, n_est;
  double *cur, cur_lnlik, maxdiff, temp;

  /* allocate space for current value */
  cur = (double *)R_alloc(n_grps+3, sizeof (double));

  n_est = n_grps+3;

  for(j=0; j<n_est; j++) cur[j] = est[j];

  flag = 0; 
  cur_lnlik=0.;
  for(i=0; i<maxit; i++) {
    npmix_estep(y, n_grps, n_obs, cur, ek, eksq, maxk);
    npmix_mstep(y, n_grps, n_obs, est, ek, eksq);

    /* calculate maximum change in parameter estimates */
    maxdiff = 0.;
    for(j=0; j<n_est; j++) {
      temp = fabs(est[j] - cur[j]);
      if(temp > maxdiff) maxdiff = temp;
    }

    if(trace) { /* print tracing information */
      *lnlik = npmix_lnlik(y, n_grps, n_obs, est, maxk);
      Rprintf("%4d %11.6lf ", i+1, *lnlik-cur_lnlik);
      cur_lnlik = *lnlik;
      if(trace > 1) {
	for(j=0; j<n_est; j++) Rprintf("%7.4lf ", est[j]);
      }
      else Rprintf("%11.6lf", maxdiff);
      Rprintf("\n");
    }

    if(maxdiff < tol) { /* converged */
      flag = 1;
      break;
    }

    for(j=0; j<n_est; j++) cur[j] = est[j];
  } /* end of loop over EM iterations */

  if(!flag) warning("Didn't converge!\n");

  /* re-do E-step */
  npmix_estep(y, n_grps, n_obs, cur, ek, eksq, maxk);

  /* calculate ln likelihood */
  *lnlik = npmix_lnlik(y, n_grps, n_obs, est, maxk);
}



/**********************************************************************
 * R_npmix_em
 *
 * wrapper for npmix_em() for calling from R
 *
 **********************************************************************/

void R_npmix_em(double *y, int *n_grps, int *n_obs, double *est,
		double *lnlik, double *ek, double *eksq, 
		int *maxk, int *maxit, double *tol, int *trace)
{
  int i;
  double **p_y, **p_ek, **p_eksq;

  /* reorganize y, ek, eksq as 2-dim arrays */
  p_y = (double **)R_alloc(*n_grps, sizeof(double *));
  p_ek = (double **)R_alloc(*n_grps, sizeof(double *));
  p_eksq = (double **)R_alloc(*n_grps, sizeof(double *));
  p_y[0] = y;
  p_ek[0] = ek;
  p_eksq[0] = eksq;
  for(i=1; i < *n_grps; i++) {
    p_y[i] = p_y[i-1] + n_obs[i-1];
    p_ek[i] = p_ek[i-1] + n_obs[i-1];
    p_eksq[i] = p_eksq[i-1] + n_obs[i-1];
  }

  npmix_em(p_y, *n_grps, n_obs, est, lnlik, p_ek, p_eksq,
	   *maxk, *maxit, *tol, *trace);
}
 


/**********************************************************************
 * npmix_estep: E-step of the EM algorithm
 * 
 * Input: see npmix_em()
 **********************************************************************/

void npmix_estep(double **y, int n_grps, int *n_obs, 
		 double *est, double **ek, double **eksq, int maxk)
{
  int i, j, k;
  double a, b, sigma, *lambda, denom, temp, temp1, temp2, temp3;

  a = est[0];
  b = est[1];
  sigma = est[2];
  lambda = est+3;

  for(i=0; i<n_grps; i++) {
    for(j=0; j<n_obs[i]; j++) { 
      
      ek[i][j] = eksq[i][j] = denom = 0.;
      for(k=0; k<maxk; k++) {
	/* From R's math library: */
	/* dnorm(double x, double mu, double sigma, int give_log) */
	/* dpois(double x, double lambda, int give_log) */

	temp = dpois((double)k, lambda[i], 0) * dnorm(y[i][j], a+b*(double)k, sigma, 0);

	denom += temp;
	ek[i][j] += (double)k * temp;
	eksq[i][j] += (double)(k*k) * temp;
      }
      ek[i][j] /= denom;
      eksq[i][j] /= denom;

    }
  }
}


/**********************************************************************
 * npmix_mstep: M-step of the EM algorithm
 * 
 * Input: see npmix_em()
 **********************************************************************/

void npmix_mstep(double **y, int n_grps, int *n_obs, 
		 double *est, double **ek, double **eksq)
{
  int i, j, k, n;
  double s_y, s_y_ek, s_ysq, s_ek, s_eksq;

  /* calculate the sufficient statistics */
  s_y = s_y_ek = s_ysq = s_ek = s_eksq = 0.;
  n = 0; 
  for(i=0; i<n_grps; i++) { 
    n += n_obs[i]; 
    est[i+3] = 0.;

    for(j=0; j<n_obs[i]; j++) { 
      est[i+3] += ek[i][j];

      s_y += y[i][j]; 
      s_y_ek += (y[i][j]*ek[i][j]);
      s_ysq += (y[i][j]*y[i][j]);
      s_ek += ek[i][j];
      s_eksq += eksq[i][j];
    }

    est[i+3] /= (double)n_obs[i];
  }

  est[1] = (s_y_ek - s_y*s_ek/(double)n) / (s_eksq - s_ek*s_ek/(double)n);
  est[0] = (s_y - est[1]*s_ek)/(double)n;
  est[2] = sqrt((s_ysq + (double)n*est[0]*est[0] + est[1]*est[1]*s_eksq -
		 2.*est[0]*s_y - 2.*est[1]*s_y_ek + 2.*est[0]*est[1]*s_ek)/(double)n);
}

/**********************************************************************
 * npmix_lnlik: Calculate ln likelihood 
 * 
 * Input: see npmix_em()
 **********************************************************************/

double npmix_lnlik(double **y, int n_grps, int *n_obs, 
		   double *est, int maxk)
{
  int i, j, k;
  double lnlik, temp, a, b, sigma, *lambda;

  a = est[0];
  b = est[1];
  sigma = est[2];
  lambda = est+3;

  lnlik = 0.;
  for(i=0; i<n_grps; i++) {
    for(j=0; j<n_obs[i]; j++) {

      temp = 0.;
      for(k=0; k<maxk; k++)
	temp += dpois((double)k, lambda[i], 0) * 
	  dnorm(y[i][j], a+b*(double)k, sigma, 0);

      lnlik += log(temp);
    }
  }

  return(lnlik);
}

/* end of npmix.c */

