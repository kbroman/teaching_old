######################################################################
#
# convolve.R
#
# Karl W Broman, Johns Hopkins University
# 9 Dec 2003
#
# Example for Statistical Computing (140.776), taken from "Writing
# R Extenstion" ver 1.8.1
# 
# Contains: conv 
######################################################################

conv <-
function(a, b)
{

  if(!is.loaded(symbol.C("R_conv"))) {
    lib.file <- file.path(paste("convolve", .Platform$dynlib.ext, sep=""))
    dyn.load(lib.file)
    cat(" -Loaded ", lib.file, "\n")
  }

  na <- length(a)
  nb <- length(b)

  if(na<1 || nb<1) stop("a and b must be of non-zero length")

  output <- .C("R_conv",
               as.double(a),
               as.double(b),
               as.integer(na),
               as.integer(nb),
               ab=as.double(rep(0,na+nb-1)))

  output$ab
}

# end of convolve.R
