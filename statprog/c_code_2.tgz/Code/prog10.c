/**********************************************************************
 * 
 * prog10.c
 *
 * Karl W Broman, Johns Hopkins University
 * 7 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "prog10.h"

int main()
{
  int ncol, nrow;    /* prog10.c */
  int i, j;
  double *x, **X;
    
  nrow=20; ncol=10; 
  x = dvector(10*20);
  X = reorg_dmatrix(x, nrow, ncol);

  for(i=0; i<nrow; i++) {
    for(j=0; j<ncol; j++) {
      X[j][i] = sqrt(i+j+2);
      printf(" %7.4lf", X[j][i]);
    }
    printf("\n");
  }

  return(0);
}



/* allocate space for a vector of n doubles */
double *dvector(int n)
{
  double *x;

  x = (double *)calloc(n, sizeof(double));

  if(x==NULL) { 
    printf("Error: no space for %d doubles\n", n);
    exit(1);
  }

  return(x);
}


/* reorganize a vector of nrow*ncol doubles, organized by columns,
   to be indexed as a matrix, though it needs to be called as
   mymatrix[col][row] */
double **reorg_dmatrix(double *x, int nrow, int ncol)
{
  int i;
  double **newx;
    
  newx = (double **)calloc(ncol, sizeof(double *));
  if(newx==NULL) {
    printf("Error: out of memory in reorg_dmatrix\n");
    exit(1);
  }

  newx[0] = x;
  for(i=1; i<nrow; i++) newx[i] = newx[i-1] + nrow;

  return(newx);
}

/* end of prog10.c */
