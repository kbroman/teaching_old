/**********************************************************************
 * 
 * npmix.h
 *
 * Karl W Broman, Johns Hopkins University
 * 1 Dec 2003
 *
 * Code for getting MLEs via the EM algorithm for a normal/Poisson
 * mixture model.  Written as an illustration for the course
 * 140.776 (Statistical computing).
 *
 * The problem:
 * 
 * m groups, n_i values in group i.  
 * y_ij: quantitative responses (j=1...n_i, i=1...m)
 * k_ij: unobserved counts
 *
 * (k_ij, y_ij) mutually independent
 * k_ij ~ Poisson(lambda_i)
 * y_ij | k_ij ~ Normal(mean=a + b k_ij, sd = sigma)
 *
 * Obtain MLEs of a, b, sigma, lambda_1 ..., lambda_m by EM
 *
 * Contains: npmix_em, R_npmix_em, npmix_estep, npmix_mstep,
 *           npmix_lnlik
 *
 **********************************************************************/

/**********************************************************************
 * npmix_em
 *
 * The main function for the EM algorithm
 *
 * Input:
 * 
 *     y        The data referred to as y[group][obs within group]
 *     n_grps   The number of groups ("m")
 *     n_obs    The number of observations per group [length n_grps]
 *     est      On entry, the starting points for the parameter 
 *                  estimates [length n_grps+3]; on exit, the estimates
 *                  themselves.
 *     lnlik    On exit, the value of the log likelihood evaluated at
 *                  the converged values of the estimates
 *     ek       On exit, E(k | y, est) [same structure as y]
 *     eksq     On exit, E(k^2 | y, est) [same structure as y]
 *
 **********************************************************************/
 
void npmix_em(double **y, int n_grps, int *n_obs, double *est,
	      double *lnlik, double **ek, double **eksq, 
	      int maxk, int maxit, double tol, int trace);

/**********************************************************************
 * R_npmix_em
 *
 * wrapper for npmix_em() for calling from R
 *
 **********************************************************************/

void R_npmix_em(double *y, int *n_grps, int *n_obs, double *est,
		double *lnlik, double *ek, double *eksq, 
		int *maxk, int *maxit, double *tol, int *trace);

/**********************************************************************
 * npmix_estep: E-step of the EM algorithm
 * 
 * Input: see npmix_em()
 **********************************************************************/

void npmix_estep(double **y, int n_grps, int *n_obs, 
		 double *est, double **ek, double **eksq, int maxk);

/**********************************************************************
 * npmix_mstep: M-step of the EM algorithm
 * 
 * Input: see npmix_em()
 **********************************************************************/

void npmix_mstep(double **y, int n_grps, int *n_obs, 
		 double *est, double **ek, double **eksq);

/**********************************************************************
 * npmix_lnlik: Calculate ln likelihood 
 * 
 * Input: see npmix_em()
 **********************************************************************/

double npmix_lnlik(double **y, int n_grps, int *n_obs, 
		   double *est, int maxk);

/* end of npmix.h */

