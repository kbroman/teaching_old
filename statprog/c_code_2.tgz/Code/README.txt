------------------------------ README.txt ------------------------------
Karl W Broman, Johns Hopkins University
8 Dec 2003

These files are example programs from the second C programming lecture
in Statistical Computing (140.776).

1. "prog10.c" shows how to use the functions dvector and
   reorg_dmatrix.  It uses the header file "prog10.h".  
   Compile it as follows:

       gcc -Wall -o prog10 prog10.c -lm


2. convolve.R, convolve.c are for convolving two finite sequences:
   a simple example for demonstrating how to call C from R. 

   convolve.c contains the C code.
   Create a shared library (for loading into R) as follows:

       R CMD SHLIB convolve.c

   This will create a shared library "convolve.so".

   convolve.R contains the R code....it has a function for simulating
   data and a function to call the C code in convolve.c.  Try the
   following:

       source("convolve.R")
       x <- dbinom(0:5,5,0.2)
       y <- dbinom(0:4,4,0.9)
       z <- conv(x,y)


3. npmix.R, npmix.c and npmix.h are for the normal/Poisson mixture
   model example.  (Obtaining MLEs by the EM algorithm.)

   npmix.c contains the C code; npmix.h is its headerfile.
   Create a shared library (for loading into R) as follows:

       R CMD SHLIB npmix.c

   This will create a shared library "npmix.so".

   npmix.R contains the R code....it has a function for simulating
   data and a function to call the C code in npmix.c.  Try the
   following:

       source("npmix.R")
       theta <- c(10, 3, 1, 0:4+0.1)
       mydata <- npmix.sim(c(50,60,70,80,90), theta)
       output <- npmix.em(mydata, start=theta)
       output$est

-------------------------- end of README.txt ---------------------------
