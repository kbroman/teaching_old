/**********************************************************************
 * 
 * convolve.c
 *
 * Karl W Broman, Johns Hopkins University
 * 9 Dec 2003
 *
 * Example for Statistical Computing (140.776), taken from "Writing
 * R Extenstion" ver 1.8.1
 * 
 * Contains: conv (the function to do the convolution)
 *           R_conv (a wrapper for calling it from R)
 **********************************************************************/

/**********************************************************************
 * conv: A function to convolve two finite sequences
 * 
 * Input: a, b    the two sequences
 *        na,nb   their lengths
 *        ab      the result, of length na+nb-1
 *
 **********************************************************************/
void conv(double *a, double *b, int na, int nb, double *ab)
{
  int i, j, nab = na + nb - 1;

  for(i=0; i<nab; i++) ab[i] = 0.0;

  for(i=0; i<na; i++)
    for(j=0; j<nb; j++)
      ab[i+j] += a[i]*b[j];
}

/**********************************************************************
 * R_conv: a wrapper for calling conv() from R
 *
 **********************************************************************/
void R_conv(double *a, double *b, int *na, int *nb, double *ab)
{
  conv(a, b, *na, *nb, ab);
}

/* end of convolve.c */
