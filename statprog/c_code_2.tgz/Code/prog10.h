/**********************************************************************
 * 
 * prog10.h
 *
 * Karl W Broman, Johns Hopkins University
 * 7 Dec 2003
 *
 **********************************************************************/

/* allocate space for a vector of n doubles */
double *dvector(int n);

/* reorganize a vector of nrow*ncol doubles, organized by columns,
   to be indexed as a matrix, though it needs to be called as
   mymatrix[col][row] */
double **reorg_dmatrix(double *x, int nrow, int ncol);

/* end of prog10.h */
