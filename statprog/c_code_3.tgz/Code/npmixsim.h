/**********************************************************************
 * 
 * npmixsim.h
 *
 * Karl W Broman, Johns Hopkins University 
 * 9 Dec 2003
 *
 * This is example code for Statistical Computing (140.776).
 *
 * Simulate from a normal/Poisson mixture:
 * 
 *   (k_ij, y_ij) mutually independent, for i=1,...,m and j=1,...,n_i
 *   k_ij  ~  Poisson(lambda_i)
 *   y_ij | k_ij ~ normal(a + b k_ij, sd=sigma)
 *
 * Contains: npmixsim, R_npmixsim
 *
 **********************************************************************/

/**********************************************************************
 * 
 * npmixsim: the simulation function
 *
 * INPUT:
 *     y        The data (on output), y[group][obs within group]
 *     n_grps   The number of groups
 *     n_obs    The number of observations per group
 *              [length n_grps]
 *     param    The parameters = (a, b, sigma, lambda's) 
 *              [length 3+n_grps]
 *
 **********************************************************************/

void npmixsim(double **y, int n_grps, int *n_obs, double *param);

/**********************************************************************
 * 
 * R_npmixsim: A wrapper for calling npmixsim() from R
 *
 **********************************************************************/
void R_npmixsim(double *y, int *n_grps, int *n_obs, double *param);

/* end of npmixsim.h */
