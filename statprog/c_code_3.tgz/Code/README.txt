------------------------------ README.txt ------------------------------
Karl W Broman, Johns Hopkins University
9 Dec 2003

These files are example programs from the second C programming lecture
in Statistical Computing (140.776).

1. npmixsim.R, npmixsim.c and npmixsim.h are for the simulating from a
   normal/Poisson mixture model.

   npmixsim.c contains the C code; npmixsim.h is its headerfile.
   Create a shared library (for loading into R) as follows:

       R CMD SHLIB npmixsim.c

   This will create a shared library "npmixsim.so".

   npmixsim.R contains the R code.  Try the following:

       source("npmixsim.R")
       theta <- c(10, 3, 1, 0:4+0.1)
       mydata <- npmixsim(c(50,60,70,80,90), theta)

-------------------------- end of README.txt ---------------------------
