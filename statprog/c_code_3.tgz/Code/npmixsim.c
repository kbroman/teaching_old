/**********************************************************************
 * 
 * npmixsim.c
 *
 * Karl W Broman, Johns Hopkins University 
 * 9 Dec 2003
 *
 * This is example code for Statistical Computing (140.776).
 *
 * Simulate from a normal/Poisson mixture:
 * 
 *   (k_ij, y_ij) mutually independent, for i=1,...,m and j=1,...,n_i
 *   k_ij  ~  Poisson(lambda_i)
 *   y_ij | k_ij ~ normal(a + b k_ij, sd=sigma)
 *
 * Contains: npmixsim, R_npmixsim
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <R.h>
#include <Rmath.h>
#include "npmixsim.h"

/**********************************************************************
 * 
 * npmixsim: the simulation function
 *
 * INPUT:
 *     y        The data (on output), y[group][obs within group]
 *     n_grps   The number of groups
 *     n_obs    The number of observations per group
 *              [length n_grps]
 *     param    The parameters = (a, b, sigma, lambda's) 
 *              [length 3+n_grps]
 *
 **********************************************************************/

void npmixsim(double **y, int n_grps, int *n_obs, double *param)
{
  int i, j;
  double a=param[0], b=param[1], sigma=param[2], *lambda=param+3;

  GetRNGstate();

  for(i=0; i<n_grps; i++) 
    for(j=0; j<n_obs[i]; j++) 
      y[i][j] = rnorm(a+b*rpois(lambda[i]), sigma);

  PutRNGstate();
  
}



/**********************************************************************
 * 
 * R_npmixsim: A wrapper for calling npmixsim() from R
 *
 **********************************************************************/
void R_npmixsim(double *y, int *n_grps, int *n_obs, double *param)
{
  double **Y;
  int i;

  Y = (double **)R_alloc(*n_grps, sizeof(double *));
  Y[0] = y;
  for(i=1; i < *n_grps; i++) 
    Y[i] = Y[i-1] + n_obs[i-1];
  
  npmixsim(Y, *n_grps, n_obs, param);
}

/* end of npmixsim.c */
