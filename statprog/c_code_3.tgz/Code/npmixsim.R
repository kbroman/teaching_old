######################################################################
# 
# npmixsim.R
#
# Karl W Broman, Johns Hopkins University 
# 9 Dec 2003
#
# This is example code for Statistical Computing (140.776).
#
# Simulate from a normal/Poisson mixture:
# 
#   (k_ij, y_ij) mutually independent, for i=1,...,m and j=1,...,n_i
#   k_ij  ~  Poisson(lambda_i)
#   y_ij | k_ij ~ normal(a + b k_ij, sd=sigma)
#
# Contains: npmixsim (which calls a C function)
#
######################################################################/

npmixsim <-
function(n=c(30,30,30,30), theta=c(10,1,0.3, 0.1, 1.1, 2.1, 3.1))
{
  if(length(n)+3 != length(theta))
    stop("length(n) + 3 != length(theta)")
  
  # load the C code
  if(!is.loaded(symbol.C("R_npmixsim"))) {
    lib.file <- file.path(paste("npmixsim", .Platform$dynlib.ext, sep=""))
    dyn.load(lib.file)
    cat(" -Loaded ", lib.file, "\n")
  }

  output <- .C("R_npmixsim",
               y=as.double(rep(0,sum(n))),
               as.integer(length(n)),
               as.integer(n),
               as.double(theta))
               
  y <- vector("list",length(n))
  csn <- c(0,cumsum(n))
  for(i in 1:length(n)) 
    y[[i]] <- output$y[(csn[i]+1):csn[i+1]]

  y
}

# end of npmixsim.R
