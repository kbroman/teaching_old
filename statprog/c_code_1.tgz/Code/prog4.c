/**********************************************************************
 * 
 * prog4.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>

int main() 
{
  double x;
  double *dp;
    
  x = 12.0;
  dp = &x;
    
  printf("%g\n", *dp);
  printf("%x\n", dp);
  /*  printf("%x\n", (unsigned int)dp); */

  return(0);
}

/* end of prog4.c */
