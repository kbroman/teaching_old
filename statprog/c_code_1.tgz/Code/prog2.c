/**********************************************************************
 * 
 * prog2.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <math.h>
#include <stdio.h>

int main() 
{
  int i;
  double x;
  
  i = 3;
  x = sqrt( (double)i); /* NOT x = sqrt(i); */

  printf("%f\n", x);

  return(0);
}
 
/* end of prog2.c */
