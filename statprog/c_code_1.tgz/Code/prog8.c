/**********************************************************************
 * 
 * prog8.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i, j, k, dim1=4, dim2=5, dim3=3;
  int ***x, *temp;

  temp = (int *)calloc(dim1*dim2*dim3, sizeof(int));
  if(temp==NULL) { 
    printf("Error: Cannot allocate space for temp\n");
    exit(EXIT_FAILURE);
  }

  x = (int ***)calloc(dim1, sizeof(int **));
  if(x==NULL) {
    printf("Error: Cannot allocate space for x\n");
    exit(EXIT_FAILURE);
  }
  for(i=0; i<dim1; i++) {
    x[i] = (int **)calloc(dim2, sizeof(int *));
    if(x[i]==NULL) {
      printf("Error: Cannot allocate space for x[%d]\n", i);
      exit(EXIT_FAILURE);
    }

    /* make things point properly */
    for(j=0; j<dim2; j++) x[i][j] = temp+(i*dim2+j)*dim3;
  }
  
  for(i=0; i<dim1; i++) {
    for(j=0; j<dim2; j++) {
      for(k=0; k<dim3; k++) {
	x[i][j][k] = i+j+k;

	printf(" (%d,%d,%d)  addr=%u  value=%d\n", 
	       i, j, k, (unsigned int)&(x[i][j][k]), x[i][j][k]);
      }
    }
  }

  for(i=0; i<dim1; i++) free(x[i]);
  free(x); 
  free(temp);

  return(0);
}

/* end of prog8.c */
