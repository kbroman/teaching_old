/**********************************************************************
 * 
 * prog7b.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i, j, nr=3, nc=6;
  int *x;

  x = (int *)calloc(nr*nc, sizeof(int));
  if(x==NULL) {
    printf("Error: Cannot allocate space for x\n");
    exit(EXIT_FAILURE);
  }

  for(i=0; i<3; i++) {
    for(j=0; j<6; j++) {
      x[i + j*nr] = i+j; /* stored by columns */
      
      printf(" row=%d col=%d  addr=%u  value=%d\n", 
	     i, j, (unsigned int)(x+i+j*nr), x[i+j*nr]);
    }
  }

  free(x);

  return(0);
}

/* end of prog7b.c */
