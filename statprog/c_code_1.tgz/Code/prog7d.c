/**********************************************************************
 * 
 * prog7d.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i, j, nr=3, nc=6, **x;

  x = (int **)calloc(nr, sizeof(int *));
  if(x==NULL) {
    printf("Error: Cannot allocate space for x\n");
    exit(EXIT_FAILURE);
  }

  for(i=0; i<nr; i++) {
    x[i] = (int *)calloc(nc, sizeof(int));  
    if(x[i]==NULL) {
      printf("Error: Cannot allocate space for x[%d]\n", i);
      exit(EXIT_FAILURE);
    }
  }

  for(i=0; i<nr; i++) {
    for(j=0; j<nc; j++) {
      x[i][j] = i+j; 

      printf(" row=%d col=%d  addr=%u  value=%d\n", 
	     i, j, (unsigned int)&(x[i][j]), x[i][j]);
    }
  }

  for(i=0; i<nr; i++) free(x[i]);
  free(x); 

  return(0);
}

/* end of prog7d.c */
