/**********************************************************************
 * 
 * prog3.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>

int main() 
{
  int i;
  
  i=0;
  while(1) {
    i++;
    if(i % 2) continue;
    printf("  %2d %2d\n", i, i % 2);
    if(i>10) break;
  }

  return(0);
}

/* end of prog3.c */
