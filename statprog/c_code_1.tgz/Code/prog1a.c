/**********************************************************************
 * 
 * prog1a.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

main()               
{
    double x, y;         /* declare two doubles */

    printf("Enter first number: "); 
    scanf("%lf", &x);    /* lf = "long float"; & = address operator */

    printf("Enter second number: ");
    scanf("%lf", &y);

    printf("The sum is %f\n", x+y); /* \n = newline character */
}

/* end of prog1a.c */
