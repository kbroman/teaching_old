/**********************************************************************
 * 
 * prog5.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include "prog5.h"

int main() 
{
  int i=3, j=5;

  printf("  %d %d\n", i, j);

  swap(&i, &j);

  printf("  %d %d\n", i, j);

  return(0);
}

void swap(int *a, int *b)
{
  int temp;

  temp = *a;
  *a = *b;
  *b = temp;
}

/* end of prog5.c */
