/**********************************************************************
 * 
 * prog5.h
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

/* function declaration */
void swap(int *a, int *b);

/* end of prog5.h */
