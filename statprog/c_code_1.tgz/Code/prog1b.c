/**********************************************************************
 * 
 * prog1b.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>       /* contains function declarations */

int main()               /* returns an integer; has no arguments */
{
    double x, y;         /* declare two doubles */

    printf("Enter first number: ");
    scanf("%lf", &x);    /* lf = "long float"; & = address operator */

    printf("Enter second number: ");
    scanf("%lf", &y);

    printf("The sum is %f\n", x+y);

    return(0);           /* exit normally (no errors) */
}

/* end of prog1b.c */
