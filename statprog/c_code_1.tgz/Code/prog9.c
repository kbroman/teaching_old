/**********************************************************************
 * 
 * prog9.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>

int main()
{
  double x;

  printf("-->|%d|<--\n", 123); 
  printf("-->|%5d|<--\n", 123); 
  printf("-->|%-5d|<--\n", 123);  

  printf("\n");

  printf("-->|%s|<--\n", "hello");  
  printf("-->|%9s|<--\n", "hello");  
  printf("-->|%-9s|<--\n", "hello");

  printf("\n");

  x = -17.89306213;
  printf("-->|%f|<--\n", x);
  printf("-->|%7.2f|<--\n", x);

  printf("\n");

  printf("-->|%e|<--\n", x);
  printf("-->|%g|<--\n", x);


  return(0);
}

/* end of prog9.c */
