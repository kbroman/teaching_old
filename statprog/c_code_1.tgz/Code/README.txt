------------------------------ README.txt ------------------------------
Karl W Broman, Johns Hopkins University
3 Dec 2003

These files are various example C programs from the first C
programming lecture in Statistical Computing (140.776).

Each file is a separate program.  Note that "prog5.c" has a 
header file, "prog5.h".  

Compile the programs using something like the following:

    gcc -Wall -o prog5 prog5.c -lm

This will create an exectuable "prog5", which you can run by just
typing the name.

Note that the "-lm" may not be necessary...it "links" the math
library.  (We'll discuss this more in the second lecture.)

You may also wish to try out the program "lint" for checking C code.  
Type something like the following:

    link prog5.c

-------------------------- end of README.txt ---------------------------
