/**********************************************************************
 * 
 * prog7c.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i, j, nr=3, nc=6, **x, *temp;

  temp = (int *)calloc(nr*nc, sizeof(int));
  x = (int **)calloc(nr, sizeof(int *));
  if(temp==NULL || x==NULL) {
    printf("Error: Cannot allocate space for temp and x\n");
    exit(EXIT_FAILURE);
  }

  for(i=0; i<nr; i++) x[i] = temp+i*nc;  /* stored by rows */

  for(i=0; i<nr; i++) {
    for(j=0; j<nc; j++) {
      x[i][j] = i+j; 

      printf(" row=%d col=%d  addr=%u  value=%d\n", 
	     i, j, (unsigned int)&(x[i][j]), x[i][j]);
    }
  }
  free(x); 
  free(temp);

  return(0);
}

/* end of prog7c.c */
