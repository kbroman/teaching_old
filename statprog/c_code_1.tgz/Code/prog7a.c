/**********************************************************************
 * 
 * prog7a.c
 *
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <stdio.h>

int main()
{
  int i, j;
  int x[3][6];    /* 3 rows and 6 columns */ 
                  /* stored by rows */

  for(i=0; i<3; i++) {
    for(j=0; j<6; j++) {
      x[i][j] = i+j;

      printf(" row=%d col=%d  addr=%u  value=%d\n", 
	     i, j, (unsigned int)&x[i][j], x[i][j]);
    }
  }

  return(0);
}

/* end of prog7a.c */
