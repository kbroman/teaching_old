/**********************************************************************
 * 
 * prog6.c
 * 
 * Karl W Broman, Johns Hopkins University
 * 2 Dec 2003
 *
 **********************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main() 
{
  double *x, *y;    
  int n, i;

  n=20;

  x = (double *)malloc(n*sizeof(double));
  y = (double *)calloc(n, sizeof(double));
  if(x==NULL || y==NULL) {
    printf("Error: cannot allocate space for x and y\n");
    exit(EXIT_FAILURE);
  }

  for(i=0; i<20; i++) {
    x[i] = sqrt((double)i);
    y[i] = (double)(i*i);
    printf("  %2d %7.5f %8.3f\n", i, x[i], y[i]);
  }

  free(x);
  free(y);

  return(0);
}

/* end of prog6.c */
